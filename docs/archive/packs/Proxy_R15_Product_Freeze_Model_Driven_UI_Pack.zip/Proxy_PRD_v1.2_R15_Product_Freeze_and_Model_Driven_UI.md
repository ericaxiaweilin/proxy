# Proxy PRD v1.2
## R15 — Product Freeze + Model-Driven UI

**状态**：PRODUCT FREEZE / FRONTEND ARCHITECTURE RESET

## 1. Freeze

R15 开始冻结：
```text
One App
One Account
Active Context = REQUESTER | AGENT | BUSINESS

Root Navigation
Home / Tasks / Feed / Me
```

不再因为新增场景继续新增 Root 或 Persona App。

## 2. Stable Surfaces

P0 稳定 Surface：
```text
RootHome
RootTasks
RootFeed
RootMe

FulfillmentWorkspace
SkillWorkspace
Conversation
AgentProfile
MerchantStorefront
ActivityDetail
OrderExecution
Outcome
```

业务场景默认不再新增 Page。

## 3. Core Architecture

```text
Hard Demand Category
→ Natural-language Goal
→ Unified Model Runtime
→ DemandPlan
→ UIPlan
→ UI Orchestrator
→ Component Registry
→ Stable Surface
→ Domain Runtime / Truth
```

## 4. Model-Driven ≠ Model-Generated Page

禁止：
```text
LLM → arbitrary HTML
LLM → arbitrary route
```

允许：
```json
{
  "surface": "FULFILLMENT_WORKSPACE",
  "panels": [
    "GOAL_SUMMARY",
    "TIME_LOCATION",
    "ROUTE",
    "CANDIDATE_RAIL",
    "CONTEXTUAL_QUOTE"
  ]
}
```

前端只从固定 Component Registry 拉组件。

## 5. Responsibility

Model：
```text
理解目的
读取允许的上下文
选择 Task Archetype
整理已知 / 推断 / 缺失事实
选择 UI Components
生成摘要
```

UI Orchestrator：
```text
schema validation
component allowlist
permission check
surface compatibility
panel ordering / dedupe
navigation budget
read-model hydration
render
```

Domain Runtime：
```text
Need / Task / Requirement / Candidate / Order / Settlement / Outcome truth
eligibility
availability
conflict
funding
permission
```

## 6. Hard Demand Category

继续冻结：
```text
FNB_RETAIL
EVENT_EXHIBITION
TRAVEL_LOCAL
BUSINESS_PRO
CONTENT_MARKETING
MOBILITY_ERRAND
OTHER
```

模型不得静默跨 Category。

## 7. Persona

Requester：
```text
Home
→ Hard Category + Goal
→ FulfillmentWorkspace
```

Agent：
```text
Home
→ qualified demand / order / reply
```

Business：
```text
Home
→ business operations
```

Enterprise Ops：
```text
SkillWorkspace
```

## 8. Product Freeze Rule

新增能力优先顺序：
```text
1. 现有 Component 能否处理？
2. Component 是否只需新增 props / state？
3. 是否只需注册一个新 Component？
4. 最后才考虑新 Surface。
```

不再第一反应：
> 新做一个页面。

## 9. New Surface Gate

只有满足至少一个才允许新增：
```text
独立生命周期
独立导航语义
长期可返回对象
强安全 / 权限边界
无法合理放入已有 Workspace
```

`Select Language / Choose Time / Candidate Compare / Price Review`
通常不属于独立 Surface。

## 10. Navigation Budget

Requester Normal：
```text
target = 2 page switches
hard max = 5
```

UIPlan 改变 Workspace 内容，不新增 Route。

## 11. Streaming

模型可逐步输出：
```text
UI_PLAN_START
UI_PANEL_ADD
UI_PANEL_PATCH
UI_PLAN_COMPLETE
```

Goal 理解后先渲染 Goal；
Candidate 到了再追加 Candidate Rail；
Quote 到了再追加 Quote。

## 12. Model Provider

产品层只依赖：
```text
Unified Model Runtime
```

底层可由用户自己的模型底座路由：
```text
GPT
Claude
Gemini
future high-quality model
```

Frontend / Domain 不绑定 Provider。

## 13. R15 Implementation Rule

当前大 HTML 原型从此转为：
```text
Product Reference
```

不再继续承担生产架构演进。

下一阶段：
```text
extract shell
extract stable surfaces
extract components
build registry
build UIPlan renderer
build deterministic fixtures
connect model runtime
connect real API
```

## 14. Success Example

新增：
> 酒店神秘客

不应该产生 8 个新页面。

只需：
```text
Task Archetype = HOTEL_EXPERIENCE_CHECK

UIPlan:
GOAL_SUMMARY
VENUE
PARTICIPANT_MIX
EVIDENCE_PLAN
DELIVERABLE
CONTEXTUAL_QUOTE
```

如果组件已存在：
```text
0 new pages
```

## 15. 一句话

> **以后不是继续设计页面，而是设计可被模型调用的产品组件。**
