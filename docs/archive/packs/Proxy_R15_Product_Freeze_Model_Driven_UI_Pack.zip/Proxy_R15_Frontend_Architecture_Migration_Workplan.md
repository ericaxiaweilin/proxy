# Proxy R15 — Frontend Architecture Migration Workplan

## Phase 0 — Freeze
- Freeze R14.10 as product reference.
- No new normal page without architecture review.
- Inventory current routes.
- Mark each route:
  - STABLE_SURFACE
  - COMPONENT_CANDIDATE
  - LEGACY_ADVANCED
  - DELETE_LATER

## Phase 1 — App Shell
Extract:
```text
AppShell
RootNav
Header
ModalHost
SheetHost
ContextProvider
```

## Phase 2 — Stable Surfaces
Create:
```text
RequesterHome
AgentHome
BusinessHome
Tasks
Feed
Me
FulfillmentWorkspace
SkillWorkspace
Conversation
Profile
Storefront
OrderExecution
Outcome
```

## Phase 3 — Component Registry
Extract:
```text
GoalSummary
TimeLocation
Route
CandidateRail
Quote
TeamPlan
CriticalQuestion
WaitingStatus
...
```

Build:
```text
componentRegistry.ts
```

## Phase 4 — UIPlan Renderer
Build:
```text
UIPlanRenderer
PanelRenderer
UIPlanValidator
FallbackPlanResolver
```

Input:
```text
UIPlan
```

Output:
```text
Stable Surface composition
```

## Phase 5 — Deterministic Fixtures First
Before connecting real LLM:
```text
Hard Category
+ fixture text
→ deterministic UIPlan fixture
```

Validate all key scenarios without model variance.

## Phase 6 — Unified Model Runtime Adapter
Implement:
```text
ModelRuntimeClient
```

Contract:
```text
DemandContext
→ DemandPlan / UIPlan
```

No GPT / Claude / Gemini-specific product code in frontend.

## Phase 7 — Backend Read Models
Create read models / APIs for:
```text
Need
CandidateBatch
Quote
Conversation
Order
Outcome
Merchant
AgentProfile
```

Components consume read models, not raw tables.

## Phase 8 — Remove Legacy Routing
Normal flow stops using:
```text
industry → scenario → slot → requirement
clarify
solutions
candidatecompare
checkout
```

Keep only for:
```text
debug / advanced / exception
```

## Phase 9 — Real API
Replace localStorage business truth with backend truth.

## Phase 10 — UIPlan Streaming
After non-streaming is stable:
```text
UI_PLAN_START
PANEL_ADD
PANEL_PATCH
COMPLETE
```

## Engineering Order
```text
1 Freeze
2 Shell
3 Stable surfaces
4 Components
5 Registry
6 UIPlan renderer
7 deterministic fixtures
8 Model Runtime adapter
9 real APIs
10 streaming
```

## Do Not
- Do not rewrite all screens at once.
- Do not wire model providers directly inside components.
- Do not let model output HTML.
- Do not put backend truth into UIPlan.
- Do not delete legacy capability until component replacement exists.
