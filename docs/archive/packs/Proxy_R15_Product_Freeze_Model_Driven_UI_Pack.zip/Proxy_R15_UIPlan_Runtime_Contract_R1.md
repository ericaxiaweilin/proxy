# Proxy R15 — UIPlan Runtime Contract R1

## UIPlan Example

```json
{
  "ui_plan_id": "uip_xxx",
  "schema_version": "1.0",
  "surface": "FULFILLMENT_WORKSPACE",
  "context": "REQUESTER",
  "demand_category": "TRAVEL_LOCAL",
  "task_archetype": "CITY_COMPANION",
  "title": "河内城市同行",
  "panels": [
    {
      "component_id": "GOAL_SUMMARY",
      "priority": 100,
      "data_ref": "need:need_123"
    },
    {
      "component_id": "ROUTE",
      "priority": 90,
      "data_ref": "route:draft_45"
    },
    {
      "component_id": "CANDIDATE_RAIL",
      "priority": 80,
      "data_ref": "candidate_batch:cb_88"
    },
    {
      "component_id": "CONTEXTUAL_QUOTE",
      "priority": 70,
      "data_ref": "quote:q_19"
    }
  ],
  "required_confirmations": [],
  "optional_actions": [
    "OPEN_CHAT",
    "OPEN_CANDIDATE_DETAIL"
  ],
  "navigation_policy": {
    "stay_on_surface": true
  }
}
```

## Model May
```text
select an allowed surface
select registered components
order / prioritize components
request allowed read-model references
request minimal material clarification
```

## Model May Not
```text
invent a component
invent a route
grant permission
write domain truth
execute payment
change ledger
```

## Validation
```text
schema valid?
surface allowed?
component exists?
context allowed?
permissions satisfied?
data_ref accessible?
material action legal?
navigation budget valid?
```

Failure:
```text
drop illegal panel
or
fallback UIPlan
```

## Streaming Patch
```json
{
  "ui_plan_id": "uip_xxx",
  "op": "ADD_PANEL",
  "panel": {
    "component_id": "CANDIDATE_RAIL",
    "data_ref": "candidate_batch:cb_88"
  }
}
```

## Fallback
Every Hard Demand Category must have a deterministic minimal plan.

Example:
```text
TRAVEL_LOCAL
→ GOAL_SUMMARY
→ TIME_LOCATION
→ CRITICAL_QUESTION
```
