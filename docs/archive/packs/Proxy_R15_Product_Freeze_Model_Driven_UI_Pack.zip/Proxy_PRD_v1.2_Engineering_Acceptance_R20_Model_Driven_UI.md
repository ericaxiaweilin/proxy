# Proxy PRD v1.2
## Engineering Acceptance R20 — Model-Driven UI

# Gate A — Page Freeze
New normal business scenario cannot create a new route by default.

# Gate B — Stable Surface
Every UIPlan must target a registered stable surface.

# Gate C — Component Allowlist
Every panel must reference a registered component.

# Gate D — No Model HTML
Production model output is structured only.

# Gate E — No Invented Route
Unknown routes are rejected.

# Gate F — Domain Truth Isolation
UIPlan cannot become Need / Task / Order truth.

# Gate G — Permission Recheck
UI rendering is revalidated against permissions.

# Gate H — Navigation Budget
Requester normal flow remains target 2 / max 5.

# Gate I — Fallback
Each Hard Demand Category has deterministic fallback UIPlan.

# Gate J — Fixture Tests
Every major Task Archetype has deterministic UIPlan fixtures.

# Gate K — Provider Independence
Frontend has no direct GPT / Claude / Gemini business dependency.

# Gate L — Explicit Versioning
UIPlan schema and component registry versions are explicit.

# Gate M — Observability
Requested / rendered / rejected components are logged.

# Gate N — Function Preservation
Legacy flow cannot be removed until its capabilities exist as registered components or stable surfaces.

# Gate O — Stop Monolithic Prototype Growth
R15 engineering must not continue using the single large HTML prototype as production architecture.
