# Proxy R15 — Model-Driven UI Architecture R1

## Architecture

```text
Stable App Surfaces
        ↓
UI Orchestrator
        ↓
Component Registry
        ↓
UIPlan / SkillResult
        ↓
Unified Model Runtime
        ↓
Planner / Domain Services
        ↓
Canonical Business Truth
```

## Stable Surfaces

```text
REQUESTER_HOME
AGENT_HOME
BUSINESS_HOME
TASKS
FEED
ME
FULFILLMENT_WORKSPACE
SKILL_WORKSPACE
CONVERSATION
AGENT_PROFILE
MERCHANT_STOREFRONT
ORDER_EXECUTION
OUTCOME
ACTIVITY_DETAIL
```

## UI Orchestrator

```text
intent
→ Model Runtime
→ DemandPlan
→ UIPlan
→ validate
→ policy filter
→ hydrate
→ render components
```

## Component Registration

每个组件登记：
```text
component_id
supported_surfaces[]
supported_contexts[]
required_read_model
required_permissions[]
interaction_type
material_action?
fallback_component?
```

## Security

Model output 是不可信输入：
```text
UIPlan
→ schema validation
→ registry allowlist
→ permission evaluation
→ domain policy
→ render
```

模型写出组件名字，不代表获得权限。

## State

```text
Product State:
active_context
navigation
modal / sheet
local UI state

Domain State:
need
task
candidate
order
settlement
outcome
```

UIPlan 不替代 Domain State。

## Event-driven UI

```text
AGENT_ACCEPTED
→ Waiting panel patch

ORDER_CONFIRMED
→ OrderProgress patch

QUOTE_UPDATED
→ Quote patch
```

不用再创建新页面。

## Fallback

模型不可用：
```text
Hard Category
→ deterministic fallback UIPlan
```

核心需求流程仍可工作。

## Versioning

```text
ui_plan_schema_version
component_registry_version
surface_version
```

模型每次获得兼容 Registry Manifest。

## Observability

记录：
```text
ui_plan_id
model_run_id
category
archetype
requested_components
rendered_components
rejected_components
fallback_used
page_switch_count
goal_completed
```

> Model decides composition. Product code decides what compositions are legal.
